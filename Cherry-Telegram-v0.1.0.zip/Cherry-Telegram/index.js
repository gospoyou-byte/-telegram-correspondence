/* Cherry Telegram ♡ — SillyTavern 1.19.0+
 * First playable foundation: chats, groups, channels, stories, profile,
 * persistent settings, reactions/stickers, and quiet AI generation.
 */
(() => {
    'use strict';

    const MODULE = 'cherry_telegram';
    const VERSION = '0.1.0';
    const PREFIX = '[Cherry Telegram]';
    const DEFAULTS = {
        enabled: true,
        theme: 'plum',
        username: 'your_username',
        displayName: 'My Profile',
        bio: '♡',
        avatar: '',
        aiMode: 'main',
        systemPrompt: 'Write naturally as the selected roleplay character. Stay consistent with the character card and current story. Do not control the user.',
        chats: [
            { id: 'demo-1', name: 'Дани Сака모토', username: '@dani', avatar: '🌙', type: 'private', unread: 1, messages: [
                { id: 'm1', from: 'them', text: 'Ты ещё не спишь? ♡', time: Date.now()-3600000, reactions: ['🩷'] },
                { id: 'm2', from: 'them', text: 'Я тут увидел кое-что и сразу вспомнил о тебе.', time: Date.now()-3500000, reactions: [] }
            ]},
            { id: 'demo-2', name: 'Наш маленький хаос', username: '@little_chaos', avatar: '🐈', type: 'group', unread: 0, messages: [
                { id: 'm3', from: 'them', sender: 'Акира', text: 'Кто-нибудь видел мои ключи?', time: Date.now()-7200000, reactions: ['😂'] }
            ]}
        ],
        channels: [
            { id: 'ch-1', name: 'midnight thoughts ♡', username: '@midnight_notes', description: 'мысли после полуночи', owner: 'Дани', posts: [
                { id: 'p1', text: 'Иногда самые важные слова так и остаются в черновиках.', time: Date.now()-86400000, comments: [], reactions: ['🩷','🌙'] }
            ]}
        ],
        stories: [
            { id: 's1', author: 'Дани', avatar: '🌙', text: 'late night mood', time: Date.now()-1800000, reactions: [] }
        ],
        selectedChat: 'demo-1',
        selectedTab: 'chats',
        generatedPrompt: '',
        imagePrompt: '',
        settings: { autoReply: false, includeChatContext: true, maxHistory: 20, imageAspect: '3:4' }
    };

    let state;
    let overlay;
    let activeChat = null;
    let busy = false;

    function clone(value) { return JSON.parse(JSON.stringify(value)); }
    function getContext() {
        try { return window.SillyTavern?.getContext?.() || null; } catch (e) { return null; }
    }
    function loadState() {
        const ctx = getContext();
        if (ctx?.extensionSettings) {
            if (!ctx.extensionSettings[MODULE]) ctx.extensionSettings[MODULE] = clone(DEFAULTS);
            state = Object.assign(clone(DEFAULTS), ctx.extensionSettings[MODULE]);
            state.settings = Object.assign({}, DEFAULTS.settings, ctx.extensionSettings[MODULE].settings || {});
            state.chats = Array.isArray(ctx.extensionSettings[MODULE].chats) ? ctx.extensionSettings[MODULE].chats : clone(DEFAULTS.chats);
            state.channels = Array.isArray(ctx.extensionSettings[MODULE].channels) ? ctx.extensionSettings[MODULE].channels : clone(DEFAULTS.channels);
            state.stories = Array.isArray(ctx.extensionSettings[MODULE].stories) ? ctx.extensionSettings[MODULE].stories : clone(DEFAULTS.stories);
        } else {
            try { state = Object.assign(clone(DEFAULTS), JSON.parse(localStorage.getItem(MODULE) || '{}')); }
            catch { state = clone(DEFAULTS); }
        }
        if (!state.selectedChat && state.chats[0]) state.selectedChat = state.chats[0].id;
    }
    function saveState() {
        const ctx = getContext();
        if (ctx?.extensionSettings) {
            ctx.extensionSettings[MODULE] = state;
            ctx.saveSettingsDebounced?.();
        } else {
            localStorage.setItem(MODULE, JSON.stringify(state));
        }
    }
    function esc(value='') {
        return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }
    function timeLabel(ts) {
        return new Date(ts || Date.now()).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
    }
    function toast(message) {
        if (window.toastr?.info) window.toastr.info(message, 'Cherry Telegram');
        else console.info(PREFIX, message);
    }
    function addMessage(chat, message) {
        message.id ||= `msg-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
        message.time ||= Date.now();
        message.reactions ||= [];
        chat.messages ||= [];
        chat.messages.push(message);
        saveState();
        render();
    }
    function currentChat() { return state.chats.find(c => c.id === state.selectedChat) || state.chats[0]; }

    function mountButton() {
        if (document.getElementById('cherry-telegram-open')) return;
        const button = document.createElement('div');
        button.id = 'cherry-telegram-open';
        button.className = 'cherry-launcher menu_button';
        button.title = 'Open Cherry Telegram';
        button.innerHTML = '<span>✿</span><small>CT</small>';
        button.addEventListener('click', openApp);
        const topbar = document.querySelector('#top-bar') || document.querySelector('.top-bar');
        if (topbar) topbar.appendChild(button);
        const settings = document.querySelector('#extensions_settings2');
        if (settings && !document.getElementById('cherry-telegram-settings')) {
            const row = document.createElement('div');
            row.id = 'cherry-telegram-settings';
            row.className = 'cherry-settings-row';
            row.innerHTML = '<b>Cherry Telegram ♡</b><button class="menu_button">Open Telegram</button><span class="cherry-version">v'+VERSION+'</span>';
            row.querySelector('button').addEventListener('click', openApp);
            settings.appendChild(row);
        }
    }

    function openApp() {
        if (overlay) { overlay.classList.add('is-open'); render(); return; }
        overlay = document.createElement('div');
        overlay.id = 'cherry-telegram-overlay';
        overlay.className = 'cherry-overlay';
        overlay.innerHTML = '<section class="cherry-phone" role="dialog" aria-label="Cherry Telegram"><header class="cherry-top"><div class="cherry-brand"><span class="cherry-brand-mark">♡</span><div><b>Cherry Telegram</b><small>your little private universe</small></div></div><div class="cherry-top-actions"><button data-action="minimize" title="Minimize">—</button><button data-action="close" title="Close">×</button></div></header><main class="cherry-main" id="cherry-main"></main><nav class="cherry-nav"><button data-tab="chats">♡<small>Chats</small></button><button data-tab="stories">◉<small>Stories</small></button><button data-tab="channels">▤<small>Channels</small></button><button data-tab="profile">♙<small>Profile</small></button><button data-tab="settings">⚙<small>Settings</small></button></nav></section>';
        document.body.appendChild(overlay);
        overlay.addEventListener('click', handleClick);
        overlay.addEventListener('submit', handleSubmit);
        overlay.addEventListener('change', handleChange);
        overlay.addEventListener('keydown', e => {
            if (e.key === 'Escape') closeApp();
            if (e.key === 'Enter' && e.target.matches('[data-message-input]') && !e.shiftKey) {
                e.preventDefault(); sendMessage();
            }
        });
        render();
    }
    function closeApp() { overlay?.classList.remove('is-open'); }
    function render() {
        if (!overlay) return;
        const main = overlay.querySelector('#cherry-main');
        if (!main) return;
        const tab = state.selectedTab || 'chats';
        overlay.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
        if (tab === 'chats') main.innerHTML = renderChats();
        else if (tab === 'stories') main.innerHTML = renderStories();
        else if (tab === 'channels') main.innerHTML = renderChannels();
        else if (tab === 'profile') main.innerHTML = renderProfile();
        else main.innerHTML = renderSettings();
    }
    function renderChats() {
        const chat = currentChat();
        if (!chat) return '<div class="cherry-empty">No chats yet. Create your first conversation ♡</div>';
        const list = state.chats.map(c => `<button class="cherry-chat-row ${c.id===chat.id?'selected':''}" data-chat="${esc(c.id)}"><span class="cherry-avatar">${esc(c.avatar||'♡')}</span><span class="cherry-chat-meta"><b>${esc(c.name)}</b><small>${esc(c.messages?.at(-1)?.text || 'No messages yet')}</small></span><span class="cherry-chat-time">${c.messages?.length ? timeLabel(c.messages.at(-1).time) : ''}</span></button>`).join('');
        const messages = (chat.messages||[]).map(m => `<article class="cherry-message ${m.from==='me'?'mine':''}"><div class="cherry-bubble">${m.sender?`<small class="cherry-sender">${esc(m.sender)}</small>`:''}${esc(m.text).replace(/\n/g,'<br>')}<footer>${timeLabel(m.time)} <button data-react="${esc(m.id)}" title="React">♡</button></footer>${m.reactions?.length?`<div class="cherry-reactions">${m.reactions.map(esc).join(' ')}</div>`:''}</div></article>`).join('');
        return `<div class="cherry-chat-layout"><aside class="cherry-chat-list"><div class="cherry-section-head"><b>Messages</b><button data-action="new-chat">＋</button></div>${list}</aside><section class="cherry-conversation"><div class="cherry-conversation-head"><span class="cherry-avatar">${esc(chat.avatar||'♡')}</span><div><b>${esc(chat.name)}</b><small>${chat.type==='group'?'group conversation':'last seen recently'}</small></div><button data-action="generate-reply" ${busy?'disabled':''}>✧</button></div><div class="cherry-message-list">${messages || '<div class="cherry-empty">Say hello ♡</div>'}</div><form class="cherry-composer"><button type="button" data-action="stickers" title="Stickers">☻</button><textarea data-message-input placeholder="Write a message..." rows="1"></textarea><button type="button" data-action="attach" title="Attach image">＋</button><button type="submit" class="cherry-send">➤</button></form><div class="cherry-chat-tools"><button data-action="generate-reply" ${busy?'disabled':''}>✧ Ask character to reply</button><button data-action="image-prompt">▧ Image prompt</button></div></section></div>`;
    }
    function renderStories() {
        const cards = state.stories.slice().sort((a,b)=>b.time-a.time).map(s=>`<article class="cherry-story-card"><div class="cherry-story-avatar">${esc(s.avatar||'♡')}</div><div class="cherry-story-content"><b>${esc(s.author)}</b><small>${timeLabel(s.time)}</small><p>${esc(s.text)}</p><button data-story-react="${esc(s.id)}">♡ React</button></div></article>`).join('');
        return `<div class="cherry-page"><div class="cherry-page-title"><div><h2>Stories</h2><p>little moments, shared with you</p></div><button data-action="new-story">＋ Add story</button></div>${cards||'<div class="cherry-empty">No stories yet.</div>'}</div>`;
    }
    function renderChannels() {
        const channels = state.channels.map(c=>`<section class="cherry-channel"><header><div><h3>${esc(c.name)}</h3><small>${esc(c.username||'')} · ${c.posts.length} posts</small></div><button data-channel-post="${esc(c.id)}">＋ Post</button></header><p>${esc(c.description||'')}</p>${c.posts.slice().reverse().map(p=>`<article class="cherry-post"><small>${timeLabel(p.time)}</small><p>${esc(p.text)}</p><div class="cherry-post-actions"><button data-post-react="${esc(c.id)}:${esc(p.id)}">♡ ${p.reactions?.length||0}</button><button data-post-comment="${esc(c.id)}:${esc(p.id)}">Comments (${p.comments?.length||0})</button></div>${(p.comments||[]).map(cm=>`<div class="cherry-comment"><b>${esc(cm.author)}:</b> ${esc(cm.text)}</div>`).join('')}</article>`).join('')}</section>`).join('');
        return `<div class="cherry-page"><div class="cherry-page-title"><div><h2>Channels</h2><p>posts from your little universe</p></div><button data-action="new-channel">＋ Create</button></div>${channels||'<div class="cherry-empty">No channels yet.</div>'}</div>`;
    }
    function renderProfile() {
        return `<div class="cherry-page cherry-profile"><div class="cherry-profile-avatar">${state.avatar?`<img src="${esc(state.avatar)}">`:'♡'}</div><h2>${esc(state.displayName)}</h2><p>@${esc(state.username.replace(/^@/,''))}</p><p class="cherry-bio">${esc(state.bio)}</p><form class="cherry-form" data-form="profile"><label>Display name<input name="displayName" value="${esc(state.displayName)}"></label><label>Username<input name="username" value="${esc(state.username)}"></label><label>About me<textarea name="bio">${esc(state.bio)}</textarea></label><label>Avatar image URL<input name="avatar" value="${esc(state.avatar)}" placeholder="https://..."></label><button type="submit">Save profile</button></form></div>`;
    }
    function renderSettings() {
        return `<div class="cherry-page"><div class="cherry-page-title"><div><h2>Settings</h2><p>make it feel like yours</p></div></div><form class="cherry-form" data-form="settings"><label>AI generation mode<select name="aiMode"><option value="main" ${state.aiMode==='main'?'selected':''}>Current SillyTavern connection</option><option value="separate" ${state.aiMode==='separate'?'selected':''}>Separate provider (coming in next integration stage)</option></select></label><label>AI system instructions<textarea name="systemPrompt" rows="5">${esc(state.systemPrompt)}</textarea></label><label>Maximum chat history<input type="number" name="maxHistory" min="1" max="100" value="${state.settings.maxHistory}"></label><label class="cherry-check"><input type="checkbox" name="includeChatContext" ${state.settings.includeChatContext?'checked':''}> Include current roleplay context when generating</label><label>Image aspect ratio<select name="imageAspect">${['1:1','3:4','2:3','4:3','16:9','9:16'].map(x=>`<option ${state.settings.imageAspect===x?'selected':''}>${x}</option>`).join('')}</select></label><button type="submit">Save settings</button></form><p class="cherry-note">Separate API profiles and external IF Blocks integration will be added after checking the exact provider extension and its public interface. This version does not store API keys.</p><button class="cherry-danger" data-action="reset-demo">Restore demo data</button></div>`;
    }
    async function generate(prompt, useContext=true) {
        const ctx = getContext();
        if (!ctx) throw new Error('SillyTavern context is unavailable.');
        if (state.aiMode === 'separate') throw new Error('Separate provider integration is not configured yet. Choose the current SillyTavern connection.');
        const instruction = state.systemPrompt || 'Write naturally as the roleplay character.';
        if (useContext && state.settings.includeChatContext && typeof ctx.generateQuietPrompt === 'function') {
            return await ctx.generateQuietPrompt({ quietPrompt: `${instruction}\n\n${prompt}` });
        }
        if (typeof ctx.generateRaw === 'function') return await ctx.generateRaw({ systemPrompt: instruction, prompt });
        throw new Error('This SillyTavern build does not expose a supported generation function.');
    }
    async function generateReply() {
        const chat = currentChat(); if (!chat || busy) return;
        busy = true; render();
        try {
            const history = (chat.messages||[]).slice(-Number(state.settings.maxHistory||20)).map(m=>`${m.from==='me'?'User':(m.sender||chat.name)}: ${m.text}`).join('\n');
            const result = await generate(`You are writing a Telegram message as ${chat.name}. Reply naturally and concisely, as a real chat message. You may use emojis or a fitting sticker notation like [sticker: cat_laugh]. Do not narrate actions. Do not write for the user.\n\nConversation:\n${history}\n\nReturn only the message text.`);
            addMessage(chat, {from:'them', text:String(result||'').trim() || '♡', time:Date.now()});
        } catch(e) { toast(e.message || 'Generation failed.'); }
        finally { busy = false; render(); }
    }
    function sendMessage() {
        const input = overlay.querySelector('[data-message-input]');
        const text = input?.value?.trim(); if (!text) return;
        const chat = currentChat(); if (!chat) return;
        addMessage(chat, {from:'me', text, time:Date.now()});
        if (input) input.value = '';
        if (state.settings.autoReply) generateReply();
    }
    function handleSubmit(e) {
        e.preventDefault();
        const form = e.target;
        if (form.matches('.cherry-composer')) { sendMessage(); return; }
        const data = new FormData(form);
        if (form.dataset.form === 'profile') {
            state.displayName = data.get('displayName') || 'My Profile';
            state.username = data.get('username') || 'your_username';
            state.bio = data.get('bio') || '';
            state.avatar = data.get('avatar') || '';
        } else if (form.dataset.form === 'settings') {
            state.aiMode = data.get('aiMode');
            state.systemPrompt = data.get('systemPrompt') || '';
            state.settings.maxHistory = Math.max(1, Math.min(100, Number(data.get('maxHistory')||20)));
            state.settings.includeChatContext = data.get('includeChatContext') === 'on';
            state.settings.imageAspect = data.get('imageAspect') || '3:4';
        }
        saveState(); render(); toast('Saved ♡');
    }
    function handleChange(e) {
        if (e.target.matches('[data-message-input]')) return;
    }
    function handleClick(e) {
        const b = e.target.closest('button'); if (!b) return;
        if (b.dataset.tab) { state.selectedTab = b.dataset.tab; saveState(); render(); return; }
        if (b.dataset.chat) { state.selectedChat = b.dataset.chat; saveState(); render(); return; }
        if (b.dataset.action === 'close' || b.dataset.action === 'minimize') { closeApp(); return; }
        if (b.dataset.action === 'generate-reply') { generateReply(); return; }
        if (b.dataset.action === 'new-chat') {
            const name = prompt('Contact or character name?'); if (!name) return;
            const c = {id:`chat-${Date.now()}`, name, username:'@'+name.toLowerCase().replace(/\s+/g,'_'), avatar:'♡', type:'private', unread:0, messages:[]};
            state.chats.unshift(c); state.selectedChat=c.id; saveState(); render(); return;
        }
        if (b.dataset.action === 'stickers') {
            const stickers = ['🐈','😭','😂','🫵','💗','🫂','🤨','😼','🥺','🧍','💀','✨'];
            const choice = prompt('Choose a sticker by number:\n'+stickers.map((s,i)=>`${i+1}. ${s}`).join('\n'));
            const n = Number(choice); if (n>0 && n<=stickers.length) {
                const input=overlay.querySelector('[data-message-input]'); input.value += stickers[n-1]; input.focus();
            } return;
        }
        if (b.dataset.action === 'new-story') {
            const text=prompt('What do you want to share in your story?'); if(!text) return;
            state.stories.unshift({id:`story-${Date.now()}`,author:state.displayName,avatar:state.avatar?'📷':'♡',text,time:Date.now(),reactions:[]}); saveState(); render(); return;
        }
        if (b.dataset.action === 'new-channel') {
            const name=prompt('Channel name?'); if(!name) return;
            const ch={id:`channel-${Date.now()}`,name,username:'@'+name.toLowerCase().replace(/\s+/g,'_'),description:'',owner:state.displayName,posts:[]};
            state.channels.unshift(ch); saveState(); render(); return;
        }
        if (b.dataset.channelPost) {
            const ch=state.channels.find(x=>x.id===b.dataset.channelPost); if(!ch) return;
            const text=prompt('Write a channel post:'); if(!text) return;
            ch.posts.push({id:`post-${Date.now()}`,text,time:Date.now(),comments:[],reactions:[]}); saveState(); render(); return;
        }
        if (b.dataset.postReact) {
            const [cid,pid]=b.dataset.postReact.split(':'); const p=state.channels.find(c=>c.id===cid)?.posts.find(p=>p.id===pid);
            if(p) p.reactions.push('🩷'); saveState(); render(); return;
        }
        if (b.dataset.postComment) {
            const [cid,pid]=b.dataset.postComment.split(':'); const p=state.channels.find(c=>c.id===cid)?.posts.find(p=>p.id===pid);
            const text=prompt('Write a comment:'); if(text&&p){p.comments.push({author:state.displayName,text});saveState();render();} return;
        }
        if (b.dataset.react) {
            const chat=currentChat(); const m=chat?.messages.find(x=>x.id===b.dataset.react);
            if(m){const r=prompt('Reaction emoji?','🩷');if(r)m.reactions.push(r);saveState();render();} return;
        }
        if (b.dataset.storyReact) {
            const s=state.stories.find(x=>x.id===b.dataset.storyReact); if(s){s.reactions.push('🩷');saveState();render();} return;
        }
        if (b.dataset.action === 'image-prompt') {
            const idea=prompt('Describe the image in Russian or English:'); if(!idea)return;
            (async()=>{
                try {
                    const promptText=await generate(`Create a concise, detailed English image-generation prompt from this idea. Preserve the requested subject and composition. Return only the prompt.\n\nIdea: ${idea}`, true);
                    state.generatedPrompt=String(promptText||'').trim(); saveState();
                    const copy=confirm('Generated prompt:\n\n'+state.generatedPrompt+'\n\nCopy it to clipboard?');
                    if(copy && navigator.clipboard?.writeText) await navigator.clipboard.writeText(state.generatedPrompt);
                } catch(err){toast(err.message||'Prompt generation failed.');}
            })(); return;
        }
        if (b.dataset.action === 'attach') {
            const picker=document.createElement('input'); picker.type='file'; picker.accept='image/*';
            picker.onchange=()=>{const f=picker.files?.[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{const chat=currentChat();addMessage(chat,{from:'me',text:'[Image attachment] '+f.name,image:reader.result});};reader.readAsDataURL(f);};
            picker.click(); return;
        }
        if (b.dataset.action === 'reset-demo' && confirm('Restore demo data? This replaces your current Cherry Telegram data.')) {
            state=clone(DEFAULTS); saveState(); render(); return;
        }
    }

    function init() {
        loadState();
        mountButton();
        const observer = new MutationObserver(() => mountButton());
        observer.observe(document.body, {childList:true,subtree:true});
        console.info(`${PREFIX} v${VERSION} loaded.`);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
    else init();
})();
